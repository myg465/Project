$(document).ready(function(){
	
	$(".menu_list").mouseenter(function(){
		$(this).css({"border-bottom":"2.5px solid #ff5a2a"});
	});
	$(".menu_list").mouseleave(function(){
		$(this).css({"border-bottom":""});
	});
	
	
	
});
