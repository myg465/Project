
function writeCheck(){
	var date=new date();
	if(event_write.eTitle.value==""){
		alert("제목을 입력해 주세요.");
		event_write.eTitle.focus();
		return false;
	}
	if(event_write.eTitleimg.value==""){
		alert("썸네일 이미지를 선택해 주세요.");
		event_write.eTitleimg.focus();
		return false;
	}
	if(event_write.eContentimg.value==""){
		alert("내용이미지를 선택해 주세요.");
		event_write.eContentimg.focus();
		return false;
	}
	if(event_write.eDate_end.value<date.getDate()){
		alert("이전날짜는 입력할수 없습니다."); 
		event_write.eDate_end.value=""; 
		return false; 
	}
	
	return true;
}
